/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package progettobingo;

import java.awt.Color;
import java.awt.Font;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class PaginaInserimentoDati extends javax.swing.JFrame {
    private int idPartitaCorrente;
    private String tipoVincitaRilevata = ""; 

    public PaginaInserimentoDati() {
        initComponents();
        configuraStrutturaPannelli();
        
        this.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        
        setTitle("Verifica Vincita");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        stileBottoni();
        
        panelRegistrazione.setVisible(false);
        idPartitaCorrente = DatabaseManager.getUltimaPartita();
        
        this.getRootPane().setDefaultButton(btnVerifica);
    }


    private void azioneVerifica() {
        String idStr = txtIdCartella.getText().trim();
        if(idStr.isEmpty()) return;
        int idCartella;
        try {
            idCartella = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            lblRisultatoVerifica.setText("ID non valido!");
            return;
        }
        
        List<List<Integer>> righeCartella = DatabaseManager.getNumeriCartella(idCartella); //come se si avesse una lista più grande che reppresenta la cartella e una più piccola per le 3 righe per ogni cartella
        
        if (righeCartella == null) {
            lblRisultatoVerifica.setText("Cartella inesistente!");
            lblRisultatoVerifica.setForeground(Color.RED);
            panelRegistrazione.setVisible(false);
            return;
        }

        List<Integer> estratti = DatabaseManager.getNumeriEstratti(idPartitaCorrente); //ottiene l'elenco completo dei numeri già estratti durante la partita
        
        int righeVinte = 0;
        for (List<Integer> riga : righeCartella) { //estrae una riga alla volta e la inserisce dentro riga
            if (estratti.containsAll(riga)){
                righeVinte++;
            }
        }

        // checkStatoVincite restituisce {cinquinaFatta, bingoFatto}
        boolean[] statoVincite = DatabaseManager.checkStatoVincite(idPartitaCorrente); //checkStatoVincite ritorna un array di booleani per controllare se il bingo o la cinquina sono stati gia fatti
        boolean cinquinaGiaAssegnata = statoVincite[0];
        boolean bingoGiaAssegnato = statoVincite[1];

        if (righeVinte == 3) {
            if (bingoGiaAssegnato) {
                lblRisultatoVerifica.setText("PARTITA CHIUSA (BINGO GIÀ FATTO)");
                lblRisultatoVerifica.setForeground(Color.RED);
                panelRegistrazione.setVisible(false);
                JOptionPane.showMessageDialog(this, "Il Bingo è già stato assegnato! La partita è finita.");
            } else {
                tipoVincitaRilevata = "BINGO";
                lblRisultatoVerifica.setText("BINGO!!!");
                lblRisultatoVerifica.setForeground(new Color(39, 174, 96));
                panelRegistrazione.setVisible(true);
            }
            
        } else if (righeVinte >= 1) {
            if (cinquinaGiaAssegnata) {
                lblRisultatoVerifica.setText("Cinquina già fatta. Si gioca per il Bingo.");
                lblRisultatoVerifica.setForeground(Color.GRAY);
                panelRegistrazione.setVisible(false);
            } else {
                tipoVincitaRilevata = "CINQUINA";
                lblRisultatoVerifica.setText("CINQUINA!");
                lblRisultatoVerifica.setForeground(new Color(243, 156, 18));
                panelRegistrazione.setVisible(true);
            }
        } else {
            lblRisultatoVerifica.setText("Nessuna vincita.");
            lblRisultatoVerifica.setForeground(Color.RED);
            panelRegistrazione.setVisible(false);
        }

        this.revalidate();
        this.repaint();
    }

    private void azioneSalva() {
        String nome = txtNome.getText().trim();
        String cognome = txtCognome.getText().trim();
        
        if (nome.isEmpty() || cognome.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Inserisci Nome e Cognome!");
            return;
        }
        
        int idCartella = Integer.parseInt(txtIdCartella.getText());

        try {
            DatabaseManager.registraVincitore(idPartitaCorrente, idCartella, nome, cognome, tipoVincitaRilevata);
            JOptionPane.showMessageDialog(this, "Vincita salvata correttamente!");
            dispose();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errore DB: " + ex.getMessage());
        }
    }
    
    private void stileBottoni() {
        stileSingoloBottone(btnVerifica, new Color(46, 204, 113));
        stileSingoloBottone(esciBtn, new Color(231, 76, 60));  
        stileSingoloBottone(btnSalvaVincita, new Color(52, 152, 219));
    }

    private void stileSingoloBottone(JButton btn, Color bg) {
        if(btn == null) return;
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
    }
    
    private void configuraStrutturaPannelli() {
        javax.swing.JPanel cardBianca = new javax.swing.JPanel(new java.awt.GridBagLayout());
        cardBianca.setBackground(java.awt.Color.WHITE);
        cardBianca.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(new java.awt.Color(200, 200, 200), 1),
            javax.swing.BorderFactory.createEmptyBorder(40, 40, 40, 40)
        ));

        java.awt.Dimension dimensioneCard = new java.awt.Dimension(650, 550);
        cardBianca.setPreferredSize(dimensioneCard);
        cardBianca.setMinimumSize(dimensioneCard);

        panelRegistrazione.setBackground(java.awt.Color.WHITE);
        lblTitolo.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 22));
        txtIdCartella.setPreferredSize(new java.awt.Dimension(120, 25));
        txtNome.setPreferredSize(new java.awt.Dimension(150, 25));
        txtCognome.setPreferredSize(new java.awt.Dimension(150, 25));

        javax.swing.JPanel panelId = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 15, 0));
        panelId.setBackground(java.awt.Color.WHITE);
        panelId.add(jLabel1);
        panelId.add(txtIdCartella);

        java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
        gbc.insets = new java.awt.Insets(12, 10, 12, 10);
        gbc.gridx = 0;
        gbc.gridwidth = 1;
        gbc.anchor = java.awt.GridBagConstraints.CENTER;

        gbc.gridy = 0;
        cardBianca.add(lblTitolo, gbc);

        gbc.gridy = 1;
        cardBianca.add(panelId, gbc);

        gbc.gridy = 2;
        cardBianca.add(btnVerifica, gbc);

        gbc.gridy = 3;
        cardBianca.add(lblRisultatoVerifica, gbc);

        gbc.gridy = 4;
        cardBianca.add(panelRegistrazione, gbc);

        gbc.gridy = 5;
        gbc.insets = new java.awt.Insets(40, 10, 10, 10); 
        cardBianca.add(esciBtn, gbc);

        javax.swing.JPanel pannelloSotto = new javax.swing.JPanel(new java.awt.GridBagLayout());
        pannelloSotto.setBackground(new java.awt.Color(235, 240, 245));
        pannelloSotto.add(cardBianca, new java.awt.GridBagConstraints());

        this.setContentPane(pannelloSotto);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitolo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtIdCartella = new javax.swing.JTextField();
        btnVerifica = new javax.swing.JButton();
        lblRisultatoVerifica = new javax.swing.JLabel();
        panelRegistrazione = new javax.swing.JPanel();
        txtNome = new javax.swing.JTextField();
        txtCognome = new javax.swing.JTextField();
        lblCognome = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        btnSalvaVincita = new javax.swing.JButton();
        esciBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitolo.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblTitolo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitolo.setText("VERIFICA VINCITA");

        jLabel1.setText("ID cartella: ");

        btnVerifica.setText("VERIFICA");
        btnVerifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerificaActionPerformed(evt);
            }
        });

        lblRisultatoVerifica.setText("In attesa...");

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        lblCognome.setText("Nome:");

        lblNome.setText("Cognome: ");

        btnSalvaVincita.setText("SALVA");
        btnSalvaVincita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvaVincitaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelRegistrazioneLayout = new javax.swing.GroupLayout(panelRegistrazione);
        panelRegistrazione.setLayout(panelRegistrazioneLayout);
        panelRegistrazioneLayout.setHorizontalGroup(
            panelRegistrazioneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRegistrazioneLayout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(panelRegistrazioneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelRegistrazioneLayout.createSequentialGroup()
                        .addComponent(lblNome)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 105, Short.MAX_VALUE)
                        .addComponent(txtCognome, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelRegistrazioneLayout.createSequentialGroup()
                        .addComponent(lblCognome)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(97, 97, 97))
            .addGroup(panelRegistrazioneLayout.createSequentialGroup()
                .addGap(169, 169, 169)
                .addComponent(btnSalvaVincita, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelRegistrazioneLayout.setVerticalGroup(
            panelRegistrazioneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRegistrazioneLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(panelRegistrazioneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCognome))
                .addGap(26, 26, 26)
                .addGroup(panelRegistrazioneLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCognome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNome))
                .addGap(18, 18, 18)
                .addComponent(btnSalvaVincita)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        esciBtn.setText("ESCI");
        esciBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                esciBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblTitolo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(346, 346, 346)
                .addComponent(jLabel1)
                .addGap(75, 75, 75)
                .addComponent(txtIdCartella, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(esciBtn)
                .addGap(38, 38, 38))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(407, 407, 407)
                        .addComponent(btnVerifica))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(421, 421, 421)
                        .addComponent(lblRisultatoVerifica))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(237, 237, 237)
                        .addComponent(panelRegistrazione, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(241, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblTitolo)
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtIdCartella, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(btnVerifica)
                .addGap(18, 18, 18)
                .addComponent(lblRisultatoVerifica)
                .addGap(33, 33, 33)
                .addComponent(panelRegistrazione, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(esciBtn)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btnVerificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerificaActionPerformed
        // TODO add your handling code here:
        azioneVerifica();
    }//GEN-LAST:event_btnVerificaActionPerformed

    private void btnSalvaVincitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvaVincitaActionPerformed
        // TODO add your handling code here:
        azioneSalva();
    }//GEN-LAST:event_btnSalvaVincitaActionPerformed

    private void esciBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_esciBtnActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_esciBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PaginaInserimentoDati.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PaginaInserimentoDati.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PaginaInserimentoDati.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PaginaInserimentoDati.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PaginaInserimentoDati().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvaVincita;
    private javax.swing.JButton btnVerifica;
    private javax.swing.JButton esciBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblCognome;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblRisultatoVerifica;
    private javax.swing.JLabel lblTitolo;
    private javax.swing.JPanel panelRegistrazione;
    private javax.swing.JTextField txtCognome;
    private javax.swing.JTextField txtIdCartella;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
