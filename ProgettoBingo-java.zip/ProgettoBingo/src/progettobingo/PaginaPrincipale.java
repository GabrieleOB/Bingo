/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package progettobingo;

import com.fazecast.jSerialComm.SerialPort;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.*;

public class PaginaPrincipale extends javax.swing.JFrame {
    private SerialPort port;
    private ArrayList<Integer> sacchetto;
    private Timer timerAutomatico;
    private boolean isRunning = false;
    private int idPartitaCorrente = -1; 
    private int ordineEstrazione = 1;


    private JLabel[] celleNumeri = new JLabel[91];
    
    
    public PaginaPrincipale() {
        initComponents();
        this.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null); // centrare la finestra nello schermo del computer
        riempiGriglia();
        stileBottoni();
        inizializzaSacchetto();
        setupTimer();
        connettiPorta();
        btnReset.setVisible(false);
        lblNumeroGrande.setText("--");
        lblNumeroGrande.setForeground(new Color(178, 34, 34));
    }
    
    
    private void stileBottoni() {
        stileSingoloBottone(btnStartStop, new Color(32, 201, 151)); 
        
        stileSingoloBottone(btnVerifica, new Color(108, 117, 125));  
        stileSingoloBottone(btnStorico, new Color(108, 117, 125));  
        
        stileSingoloBottone(btnReset, new Color(178, 34, 34));
    }

    private void stileSingoloBottone(JButton btn, Color colore) {
        if(btn == null) return;
        btn.setBackground(colore);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false); // togliere il tratteggio attorno al bottone quando viene premuto
    }


    private void gestioneStartStop() {
        if (!isRunning) {
            if (sacchetto.size() == 90) {
                resetGraficaTabellone();
                idPartitaCorrente = DatabaseManager.creaNuovaPartita();
                System.out.println("Nuova partita avviata.");
            }
            isRunning = true;
            btnStartStop.setText("PAUSA ESTRAZIONE");
            btnStartStop.setBackground(new Color(241, 196, 15));
            lblStato.setText("Stato: IN ESECUZIONE");
            eseguiEstrazione();
            timerAutomatico.start(); 
        } else {
            isRunning = false;
            timerAutomatico.stop();
            btnStartStop.setText("RIPRENDI ESTRAZIONE");
            btnStartStop.setBackground(new Color(46, 204, 113));
            lblStato.setText("Stato: IN PAUSA");
        }
    }

    private void eseguiEstrazione() {
        if (sacchetto.isEmpty()) {
            timerAutomatico.stop();
            isRunning = false;
            inviaAllaScheda(-1); 
            JOptionPane.showMessageDialog(this, "Tutti i numeri sono stati estratti! Il tabellone e i LED verranno resettati.");
            btnResetActionPerformed(null); 
            return;
        }

        int numero = sacchetto.remove(0);
        celleNumeri[numero].setBackground(Color.RED); 
        celleNumeri[numero].setForeground(Color.WHITE); 
        //lblStato.setText("Ultimo estratto: " + numero);

        lblNumeroGrande.setText(String.valueOf(numero)); 

        DatabaseManager.salvaEstrazione(idPartitaCorrente, numero); 
        inviaAllaScheda(numero);
    }

    private void resetGraficaTabellone() {
        for (int i = 1; i <= 90; i++) {
            celleNumeri[i].setBackground(Color.WHITE);
            celleNumeri[i].setForeground(Color.BLACK);
        }
        ordineEstrazione = 1;
    }

    private void inizializzaSacchetto() {
        sacchetto = new ArrayList<>();
        for (int i = 1; i <= 90; i++) {
            sacchetto.add(i);
        }
        Collections.shuffle(sacchetto);
    }

    private void setupTimer() {
        timerAutomatico = new Timer(3000, e -> eseguiEstrazione());
        timerAutomatico.setRepeats(true);
    }
    
    private void connettiPorta() {
        port = SerialPort.getCommPort("COM4");
        //port = SerialPort.getCommPort("/dev/ttyUSB0");
        port.setComPortParameters(115200, 8, SerialPort.ONE_STOP_BIT, SerialPort.NO_PARITY); //(budRate, impostazioni standard per la trasmissione dei bit (8 bit di dati, 1 di stop, nessun controllo errori)
        port.setComPortTimeouts(SerialPort.TIMEOUT_WRITE_BLOCKING, 0, 0); //blocca il programma finché il dato non è partito tutto --> aspettare che il pacchetto sia stato effettivamente invaito prima di inviarne un altro

        if (port.openPort()) {
            System.out.println("Porta aperta su COM4");
            port.addDataListener(new com.fazecast.jSerialComm.SerialPortDataListener() {
                @Override
                public int getListeningEvents() { //avvisare solo quando ci sono dati disponibili, rimane in attesa in background
                    return com.fazecast.jSerialComm.SerialPort.LISTENING_EVENT_DATA_AVAILABLE;
                }

                @Override
                public void serialEvent(com.fazecast.jSerialComm.SerialPortEvent event) { //scatta in automatico non appena la scheda invia qualcosa al PC
                    if (event.getEventType() != com.fazecast.jSerialComm.SerialPort.LISTENING_EVENT_DATA_AVAILABLE){ //verifica che l'evento sia effettivamente l'arrivo di dati
                       return; 
                    }
                    byte[] dati = new byte[port.bytesAvailable()]; //crea un contenitore della dimensione esatta dei dati che stanno aspettando di essere letti
                    int numLetto = port.readBytes(dati, dati.length); //preleva i byte dalla porta seriale e li mette nell'array
                    if (numLetto > 0) {
                        String messaggioDallaScheda = new String(dati).trim(); //trasforma quei byte in testo leggibile
                        System.out.println("[SCHEDA RISPONDE]: " + messaggioDallaScheda);
                        
                    }
                }
            });
        } else {
            System.out.println("Errore apertura porta COM4");
            lblStato.setText("Errore COM - Simulazione");   // esce in caso di test (scheda non collegata)
        }
    }

    private void inviaAllaScheda(int numero) {
        if (port != null && port.isOpen()) {
            try {
                String msg = "N:" + numero + "\n";
                port.writeBytes(msg.getBytes(), msg.length());
                System.out.println("Inviato hardware: " + msg.trim());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    private void riempiGriglia() {
        panelGriglia.setLayout(new java.awt.GridLayout(9, 10, 5, 5)); //layout griglia con 9 righe e 10 colonne e 5 in altezza e larghezza per ogni cella
        for (int i = 1; i <= 90; i++) {
            javax.swing.JLabel cella = new javax.swing.JLabel(String.valueOf(i), javax.swing.SwingConstants.CENTER);
            cella.setOpaque(true);
            cella.setBackground(java.awt.Color.WHITE);
            cella.setBorder(javax.swing.BorderFactory.createLineBorder(java.awt.Color.BLACK));
            cella.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 18));
            celleNumeri[i] = cella;
            panelGriglia.add(cella);
        }
        panelGriglia.revalidate();
        panelGriglia.repaint();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelComandi = new javax.swing.JPanel();
        lblStato = new javax.swing.JLabel();
        btnStartStop = new javax.swing.JButton();
        btnVerifica = new javax.swing.JButton();
        btnStorico = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        lblNumeroGrande = new javax.swing.JLabel();
        panelGriglia = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblStato.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStato.setText("PRONTO");

        btnStartStop.setText("NUOVA PARTITA");
        btnStartStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartStopActionPerformed(evt);
            }
        });

        btnVerifica.setText("VERIFICA");
        btnVerifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVerificaActionPerformed(evt);
            }
        });

        btnStorico.setText("STORICO");
        btnStorico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStoricoActionPerformed(evt);
            }
        });

        btnReset.setText("RESET");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });

        lblNumeroGrande.setFont(new java.awt.Font("Segoe UI", 0, 80)); // NOI18N
        lblNumeroGrande.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout panelComandiLayout = new javax.swing.GroupLayout(panelComandi);
        panelComandi.setLayout(panelComandiLayout);
        panelComandiLayout.setHorizontalGroup(
            panelComandiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblStato, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelComandiLayout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(panelComandiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(lblNumeroGrande, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                    .addGroup(panelComandiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(btnVerifica, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnStartStop, javax.swing.GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
                        .addComponent(btnStorico, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnReset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(35, 35, 35))
        );
        panelComandiLayout.setVerticalGroup(
            panelComandiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelComandiLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(lblStato)
                .addGap(38, 38, 38)
                .addComponent(btnStartStop, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(btnVerifica, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(btnStorico, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblNumeroGrande, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        panelGriglia.setLayout(new java.awt.GridLayout(1, 0));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(panelGriglia, javax.swing.GroupLayout.DEFAULT_SIZE, 617, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelComandi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelComandi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelGriglia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartStopActionPerformed
        // TODO add your handling code here:
        gestioneStartStop();
        btnReset.setVisible(true);
    }//GEN-LAST:event_btnStartStopActionPerformed

    private void btnVerificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerificaActionPerformed
        // TODO add your handling code here:
        new PaginaInserimentoDati().setVisible(true);
    }//GEN-LAST:event_btnVerificaActionPerformed

    private void btnStoricoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStoricoActionPerformed
        // TODO add your handling code here:
        new PaginaStorico().setVisible(true);
    }//GEN-LAST:event_btnStoricoActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        // TODO add your handling code here:
        timerAutomatico.stop();
        isRunning = false;

        // Invia -1 alla scheda per spegnere tutti i LED fisici
        inviaAllaScheda(-1);

        inizializzaSacchetto();
        resetGraficaTabellone();

        btnStartStop.setText("NUOVA PARTITA");
        btnStartStop.setBackground(new java.awt.Color(46, 204, 113));
        lblStato.setText("Stato: RESETTATO");
        btnReset.setVisible(false);
        lblNumeroGrande.setText("--");
    }//GEN-LAST:event_btnResetActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PaginaPrincipale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PaginaPrincipale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PaginaPrincipale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PaginaPrincipale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PaginaPrincipale().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnStartStop;
    private javax.swing.JButton btnStorico;
    private javax.swing.JButton btnVerifica;
    private javax.swing.JLabel lblNumeroGrande;
    private javax.swing.JLabel lblStato;
    private javax.swing.JPanel panelComandi;
    private javax.swing.JPanel panelGriglia;
    // End of variables declaration//GEN-END:variables
}
