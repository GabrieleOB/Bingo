/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progettobingo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.security.MessageDigest;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3306/bingo"; //Indica a Java di usare il driver JDBC specifico per MySQL (protocollo)
    //private static final String URL = "jdbc:mysql://db:3306/bingo";
    private static final String USER = "root";
    private static final String PASS = "";
    private static final String SECRET_KEY = "passwordBingo!!!"; 


    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes("UTF-8"));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Errore Hash Password", e);
        }
    }

    private static String criptaDato(String dato) {
        if (dato == null || dato.isEmpty()) return dato;
        try {
            SecretKeySpec key = new SecretKeySpec(SECRET_KEY.getBytes("UTF-8"), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptedBytes = cipher.doFinal(dato.getBytes("UTF-8"));
            return Base64.getEncoder().encodeToString(encryptedBytes);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String decriptaDato(String datoCriptato) {
        if (datoCriptato == null || datoCriptato.isEmpty() || datoCriptato.equals("-")) return datoCriptato;
        try {
            SecretKeySpec key = new SecretKeySpec(SECRET_KEY.getBytes("UTF-8"), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(datoCriptato));
            return new String(decryptedBytes, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
            return "Dato Corrotto";
        }
    }


    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS); 
    }

    public static boolean loginOperatore(String user, String pass) {
        String sql = "SELECT id_operatore FROM Operatori WHERE username = ? AND password = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) { 
            ps.setString(1, criptaDato(user));
            ps.setString(2, hashPassword(pass));
            ResultSet rs = ps.executeQuery(); 
            return rs.next(); 
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public static boolean registraNuovoOperatore(String user, String pass) {
        String sql = "INSERT INTO Operatori (username, password) VALUES (?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, criptaDato(user));
            pstmt.setString(2, hashPassword(pass));
            
            int rowsInserted = pstmt.executeUpdate();
            return rowsInserted > 0; 
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static int creaNuovaPartita() {
        int id = -1;
        String sql = "INSERT INTO Partite (data_ora) VALUES (NOW())";
        try (Connection conn = getConnection(); 
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { 
            pstmt.executeUpdate(); 
            ResultSet rs = pstmt.getGeneratedKeys(); 
            if (rs.next()) id = rs.getInt(1); 
            System.out.println("Nuova partita creata: ID " + id);
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
        return id;
    }

    public static void salvaEstrazione(int idPartita, int numero) {
        String sql = "INSERT INTO Numeri_estratti (id_partita, numero) VALUES (?, ?)"; 
        try (Connection conn = getConnection(); 
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idPartita); 
            pstmt.setInt(2, numero); 
            pstmt.executeUpdate(); 
        } catch (SQLException e) { 
            e.printStackTrace(); 
        }
    }

    public static boolean[] checkStatoVincite(int idPartita) {
        boolean[] risultati = {false, false}; 
        String sql = "SELECT tipo FROM Vince WHERE id_partita = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idPartita);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) { 
                String tipo = rs.getString("tipo");
                if ("CINQUINA".equalsIgnoreCase(tipo)) risultati[0] = true;
                if ("BINGO".equalsIgnoreCase(tipo)) risultati[1] = true;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return risultati;
    }

    public static void registraVincitore(int idPartita, int idCartella, String nome, String cognome, String tipo) throws SQLException {
        String sql = "INSERT INTO Vince (id_partita, id_cartella, tipo, nome, cognome) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idPartita);
            ps.setInt(2, idCartella);
            ps.setString(3, tipo);
            ps.setString(4, criptaDato(nome));
            ps.setString(5, criptaDato(cognome));
            ps.executeUpdate();
        }
    }

    public static int getUltimaPartita() {
        int id = -1;
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) { 
            ResultSet rs = stmt.executeQuery("SELECT MAX(id_partita) FROM Partite");
            if (rs.next()) id = rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return id;
    }

    public static List<Integer> getNumeriEstratti(int idPartita) {
        List<Integer> numeri = new ArrayList<>();
        String sql = "SELECT numero FROM Numeri_estratti WHERE id_partita = ? ORDER BY id_estrazione ASC";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idPartita);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) numeri.add(rs.getInt("numero"));
        } catch (SQLException e) { e.printStackTrace(); }
        return numeri;
    }

    public static List<List<Integer>> getNumeriCartella(int idCartella) {
        List<List<Integer>> righe = new ArrayList<>(); 
        String sql = "SELECT linea_1, linea_2, linea_3 FROM Cartelle WHERE id_cartella = ?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idCartella);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                righe.add(parseLinea(rs.getString("linea_1"))); 
                righe.add(parseLinea(rs.getString("linea_2")));
                righe.add(parseLinea(rs.getString("linea_3")));
                return righe;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    public static List<Object[]> getDatiStorico() {
        List<Object[]> lista = new ArrayList<>();
        
        String query = "SELECT P.id_partita, P.data_ora, " +
                       "(SELECT nome FROM Vince WHERE id_partita = P.id_partita AND tipo = 'CINQUINA' LIMIT 1) as C_Nome, " +
                       "(SELECT cognome FROM Vince WHERE id_partita = P.id_partita AND tipo = 'CINQUINA' LIMIT 1) as C_Cognome, " +
                       "(SELECT nome FROM Vince WHERE id_partita = P.id_partita AND tipo = 'BINGO' LIMIT 1) as B_Nome, " +
                       "(SELECT cognome FROM Vince WHERE id_partita = P.id_partita AND tipo = 'BINGO' LIMIT 1) as B_Cognome " +
                       "FROM Partite P ORDER BY P.data_ora DESC";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) { 
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            while (rs.next()) { 
                int id = rs.getInt("id_partita");
                Timestamp ts = rs.getTimestamp("data_ora"); 
                String dataStr = (ts != null) ? sdf.format(ts) : "N/D";
                

                String cNome = rs.getString("C_Nome");
                String cCognome = rs.getString("C_Cognome");
                String cinquina = "-";
                if (cNome != null && cCognome != null) {
                    cinquina = decriptaDato(cNome) + " " + decriptaDato(cCognome);
                }
                
                String bNome = rs.getString("B_Nome");
                String bCognome = rs.getString("B_Cognome");
                String bingo = "-";
                if (bNome != null && bCognome != null) {
                    bingo = decriptaDato(bNome) + " " + decriptaDato(bCognome);
                }

                lista.add(new Object[]{id, dataStr, cinquina, bingo});
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    private static List<Integer> parseLinea(String linea) {
        List<Integer> numeri = new ArrayList<>();
        if (linea != null && !linea.isEmpty()) {
            String[] parti = linea.split("-");
            for (String p : parti) {
                try { numeri.add(Integer.parseInt(p.trim())); } catch(NumberFormatException e){}
            }
        }
        return numeri;
    }
}