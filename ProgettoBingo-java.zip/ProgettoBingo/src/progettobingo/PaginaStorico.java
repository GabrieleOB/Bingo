/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package progettobingo;

import java.awt.Color;
import java.awt.Font;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class PaginaStorico extends javax.swing.JFrame {
    private DefaultTableModel tableModel;
    
    public PaginaStorico() {
        initComponents();
        
        configuraStrutturaPannelli();
        
        this.setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        
        setTitle("Storico Partite Bingo");
        //setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE); // quando si preme la "X" in alto chiude solo questa finestra
        configuraTabella();
        stileBottoni();
        caricaDatiStorico();
        this.getRootPane().setDefaultButton(btnChiudi);
    }
    
    private void configuraTabella() {
        String[] colonne = {"ID Partita", "Data e Ora", "Vincitore Cinquina", "Vincitore Bingo"};
        
        tableModel = new DefaultTableModel(colonne, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        
        tabellaStorico.setModel(tableModel);
        tabellaStorico.setRowHeight(25);
    }
    
    private void caricaDatiStorico() {
        tableModel.setRowCount(0); // Pulisce la tabella

        try {
            List<Object[]> righe = DatabaseManager.getDatiStorico(); // lista di oggetti perchè il database contiene dati misti
            for (Object[] riga : righe) {
                tableModel.addRow(riga);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Errore caricamento storico: " + e.getMessage());
        }
    }

    private void stileBottoni() {
        // Metodo helper locale
        stileSingoloBottone(btnChiudi, new Color(231, 76, 60));  
    }

    private void stileSingoloBottone(JButton btn, Color bg) {
        if(btn == null) return;
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
    }
    
    private void configuraStrutturaPannelli() {
        javax.swing.JPanel cardBianca = new javax.swing.JPanel(new java.awt.GridBagLayout());
        cardBianca.setBackground(java.awt.Color.WHITE);
        cardBianca.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(new java.awt.Color(200, 200, 200), 1),
            javax.swing.BorderFactory.createEmptyBorder(40, 40, 40, 40)
        ));

        java.awt.Dimension dimensioneCard = new java.awt.Dimension(850, 600);
        cardBianca.setPreferredSize(dimensioneCard);
        cardBianca.setMinimumSize(dimensioneCard);

        lblTitolo.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 22));

        java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
        gbc.gridx = 0; 
        gbc.gridwidth = 1;
        
        gbc.gridy = 0;
        gbc.insets = new java.awt.Insets(0, 10, 20, 10);
        gbc.anchor = java.awt.GridBagConstraints.CENTER;
        cardBianca.add(lblTitolo, gbc);

        gbc.gridy = 1;
        gbc.insets = new java.awt.Insets(0, 10, 20, 10);
        gbc.fill = java.awt.GridBagConstraints.BOTH; 
        gbc.weightx = 1.0; 
        gbc.weighty = 1.0; 
        cardBianca.add(jScrollPane1, gbc);

        gbc.gridy = 2;
        gbc.insets = new java.awt.Insets(10, 10, 0, 10);
        gbc.fill = java.awt.GridBagConstraints.NONE;
        gbc.weightx = 0.0; 
        gbc.weighty = 0.0;
        gbc.anchor = java.awt.GridBagConstraints.CENTER;
        cardBianca.add(btnChiudi, gbc);

        javax.swing.JPanel pannelloSotto = new javax.swing.JPanel(new java.awt.GridBagLayout());
        pannelloSotto.setBackground(new java.awt.Color(235, 240, 245)); 
        pannelloSotto.add(cardBianca, new java.awt.GridBagConstraints());

        this.setContentPane(pannelloSotto);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitolo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabellaStorico = new javax.swing.JTable();
        btnChiudi = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitolo.setText("PAGINA STORICO");

        tabellaStorico.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID partita", "Data partita", "Bingo", "Cinquina"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabellaStorico);

        btnChiudi.setText("CHIUDI");
        btnChiudi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChiudiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(402, 402, 402)
                .addComponent(lblTitolo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 819, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnChiudi)
                        .addGap(409, 409, 409))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(lblTitolo)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btnChiudi)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnChiudiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChiudiActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnChiudiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PaginaStorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PaginaStorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PaginaStorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PaginaStorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        try {
             for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(PaginaStorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PaginaStorico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChiudi;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTitolo;
    private javax.swing.JTable tabellaStorico;
    // End of variables declaration//GEN-END:variables
}
