/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progettobingo;


public class ProgettoBingo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PaginaLogin pl = new PaginaLogin();
        pl.setVisible(true);
    }
    
}
