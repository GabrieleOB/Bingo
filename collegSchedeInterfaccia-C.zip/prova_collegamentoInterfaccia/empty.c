#include "ti_msp_dl_config.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define UART_INST CONSOLE_INST
#define I2C_INST I2C_INST_INST

#define EXPANDER_1_ADDR 0x20 
#define EXPANDER_2_ADDR 0x21 

char rxBuffer[32];
int rxIndex = 0;
char txBuffer[32]; 

uint8_t ledBuffer[12] = {0};

void sendString(char *str) {
    while(*str != '\0') {
        while (DL_UART_Main_isBusy(UART_INST));
        DL_UART_Main_transmitData(UART_INST, *str);
        str++;
    }
}

void writeI2C(uint8_t deviceAddress, uint8_t registerAddress, uint8_t data) {
    DL_I2C_startControllerTransfer(I2C_INST, deviceAddress, DL_I2C_CONTROLLER_DIRECTION_TX, 2);
    
    DL_I2C_transmitControllerData(I2C_INST, registerAddress);
    
    DL_I2C_transmitControllerData(I2C_INST, data);
    
    while (DL_I2C_getControllerStatus(I2C_INST) & DL_I2C_CONTROLLER_STATUS_BUSY_BUS);
}

void attivaUscitaFisica(int numero) {
    if (numero < 1 || numero > 90) {
        return; 
    }

    int bitIndex = numero - 1; 
    
    int byteIndex = bitIndex / 8;
    
    int bitPosition = bitIndex % 8;
    
    ledBuffer[byteIndex] |= (1 << bitPosition);

    uint8_t targetAddress;
    uint8_t targetRegister;
    uint8_t targetData = ledBuffer[byteIndex];

    if (numero <= 48) {
        targetAddress = EXPANDER_1_ADDR;
        targetRegister = 0x00 + byteIndex; 
    } else {
        targetAddress = EXPANDER_2_ADDR;
        targetRegister = 0x00 + (byteIndex - 6); 
    }

    writeI2C(targetAddress, targetRegister, targetData);
}

int main(void)
{
    SYSCFG_DL_init();

    while (1) {
        if (!DL_UART_Main_isRXFIFOEmpty(UART_INST)) {
            char c = DL_UART_Main_receiveData(UART_INST);
            
            if (c == '\n') {
                rxBuffer[rxIndex] = '\0'; 
            
                if (rxBuffer[0] == 'N' && rxBuffer[1] == ':') {
                    int numeroRicevuto = atoi(&rxBuffer[2]);
                    printf("numeroRicevuto: %d\n", numeroRicevuto);
                    attivaUscitaFisica(numeroRicevuto);

                    sprintf(txBuffer, "OK:%d\n", numeroRicevuto);
                    sendString(txBuffer);
                }
                rxIndex = 0;
            } 
            else {
                if (rxIndex < 30) {
                    rxBuffer[rxIndex] = c;
                    rxIndex++;
                }
            }
        }
    }
}