# FIXED

startup_mspm0g350x_gcc.o: \
 C:/ti/mspm0_sdk_2_08_00_04/source/ti/devices/msp/m0p/startup_system_files/gcc/startup_mspm0g350x_gcc.c
